package com.myproject.haksa_config.configration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.myproject.haksa_config.dao.StudentDao;
import com.myproject.haksa_config.service.PrintStudentInfomationService;
import com.myproject.haksa_config.service.StudentAllSelectService;
import com.myproject.haksa_config.service.StudentDeleteService;
import com.myproject.haksa_config.service.StudentModifyService;
import com.myproject.haksa_config.service.StudentRegisterService;
import com.myproject.haksa_config.service.StudentSelectService;
import com.myproject.haksa_config.utils.DBConnectionInfo;
import com.myproject.haksa_config.utils.InitSampleData;

// ���������� �ڹ��� ���������� �ٷ�� Ŭ����
@Configuration
public class MemberConfig {
	@Bean
	public StudentDao studentDao() {
		return new StudentDao();
	}
	
	@Bean
	public StudentRegisterService studentRegisterService() {
		return new StudentRegisterService( studentDao() );
	}
	
	@Bean
	public InitSampleData initSampleData() {
		InitSampleData sampleData = new InitSampleData(studentRegisterService());
		sampleData.setsAges( new int[] {19,22,20,27,19}  );
		sampleData.setsGenders(new char[] {'M','W','W','M','M'});
		sampleData.setsIds(new String[] {"rabbit", "hippo", "raccoon", "elephant", "lion"});
		sampleData.setsMajors(new String[]{"English", "Korean", "French", "Philosophy", "History"});
		sampleData.setsNames(new String[]{"agatha", "barbara", "chris", "doris", "elva"});
		sampleData.setsNums(new String[] {"hbs001","hbs002","hbs003","hbs004","hbs005"});
		sampleData.setsPws(new String[]{"p0001", "p0002", "p0003", "p0004", "p0005"});
		return sampleData;
	}
	
}
