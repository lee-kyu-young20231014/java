package com.myproject.haksa_config.configration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.myproject.haksa_config.dao.StudentDao;
import com.myproject.haksa_config.service.PrintStudentInfomationService;
import com.myproject.haksa_config.service.StudentAllSelectService;
import com.myproject.haksa_config.service.StudentDeleteService;
import com.myproject.haksa_config.service.StudentModifyService;
import com.myproject.haksa_config.service.StudentRegisterService;
import com.myproject.haksa_config.service.StudentSelectService;
import com.myproject.haksa_config.utils.DBConnectionInfo;
import com.myproject.haksa_config.utils.InitSampleData;

// ���������� �ڹ��� ���������� �ٷ�� Ŭ����
@Configuration
public class MemberConfig2 {
	// bean�� �ڵ����� �Ѵ�
	@Autowired
	private StudentDao studentDao;	
	
	@Bean
	public StudentModifyService studentModifyService() {
		return new StudentModifyService(studentDao); // �����ڰ� StudentDao ��ü�� �ʿ�� �Ѵ�.
	}
	
	@Bean
	public StudentDeleteService studentDeleteService() {
		return new StudentDeleteService(studentDao);
	}
	
	@Bean
	public StudentSelectService studentSelectService() {
		return new StudentSelectService(studentDao);
	}
	
	@Bean
	public StudentAllSelectService studentAllSelectService() {
		return new StudentAllSelectService(studentDao);
	}
	
	@Bean
	public PrintStudentInfomationService printStudentInformationService() {
		return new PrintStudentInfomationService(studentAllSelectService());
	}
	
	@Bean
	public DBConnectionInfo dev_DBConnectionInfoDev() {
		DBConnectionInfo db = new DBConnectionInfo();
		db.setUrl("000.000.000.000");
		db.setUserId("admin");
		db.setUserPw("0000");
		return db;
	}
	
	@Bean
	public DBConnectionInfo real_DBConnectionInfo() {
		DBConnectionInfo db = new DBConnectionInfo();
		db.setUrl("111.111.111.111");
		db.setUserId("master");
		db.setUserPw("1111");
		return db;
	}
	
	
	
	
}
