
public class For003 {

	public static void main(String[] args) {
//		10 9 8 7 6 5 4 3 2 1 이렇게 출력하기  for문 이용
		for (int i = 10; i >=1 ; i--) {
			System.out.print(i+" ");
		}
	}

}
