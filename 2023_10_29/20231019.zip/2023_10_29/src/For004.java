
public class For004 {

	public static void main(String[] args) {
//		다음과 같은 결과물을 중첩for문을 이용해서 출력
//		출력하기 위한 출력문은 System.out.println("*"); 하나만 사용한다
//		중첩 for문인데... For003.java를 참고... 역방향
		
//		System.out.println("*****");
//		System.out.println("****");
//		System.out.println("***");
//		System.out.println("**");
//		System.out.println("*");
		for (int j = 5; j > 0 ; j--) {
			
			for (int i = 0; i < j; i++) {  // 5 4 3 2 1
				System.out.print("*");
			}
			System.out.println();
			
		}
		

	}

}
