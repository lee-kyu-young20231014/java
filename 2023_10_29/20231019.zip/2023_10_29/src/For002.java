
public class For002 {

	public static void main(String[] args) {
//		다음과 같은 결과물을 중첩for문을 이용해서 출력
//		출력하기 위한 출력문은 System.out.println("*"); 하나만 사용한다
//		System.out.println("*");
//		System.out.println("**");
//		System.out.println("***");
//		System.out.println("****");
//		System.out.println("*****");
		
		for (int i = 1; i < 6; i++) {   // i 1 ~ 5
			for (int j = 0; j < i; j++) {
				System.out.print("*"); // 같은 라인에 출력
			}
			System.out.println();  // 다음 라인으로 출력
		}
		
	}

}
