
public class Controle004 {

	public static void main(String[] args) {
		// 0~19까지의 숫자중에서 3의 배수만 제외하고 출력
		// 3의 배수 : 어떤 자연수를 3으로 나눴을대 떨어지는(0)는 수
		for (int i = 0; i < 20; i++) {
			if(i % 3 == 0) { // 3의 배수
				continue;
			}
			System.out.print(i + " ");
		}

	}

}
