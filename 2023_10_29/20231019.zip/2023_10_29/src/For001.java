
public class For001 {

	public static void main(String[] args) {
		for (int t = 2; t < 10; t++)

			for (int i = 1; i < 10; i++) {
				System.out.println(t + " x " + i + " = " + 4 * i); // num1 1
			}
		System.out.println("-----------------------------");
	}
}
