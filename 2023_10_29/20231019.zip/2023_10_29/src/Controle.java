
public class Controle {
/*
 * 순환문을 제어
 * 1. 도중에 빠져나오기  break
 * 2. 순환문의 명령어를 skip 하고 다시 한바퀴 돌기  continue
 */
	public static void main(String[] args) {
		// 1부터 99 까지 계속더하는 로직에서 그 합이 200을 넘어가면 중지
		int sum = 0;
		int i = 1;		
		for ( ; i < 100; i++) {
			sum += i;
			if(sum > 200) {
				if(true) {
					if(true) {
						break;  // depth 가 아무리깊어서 break를 감싸는 첫번재 순환문을 빠져 나온다.
					}
				}
			}
		}		
		System.out.println(sum);
		System.out.println(i);
		System.out.println(1+2+3+4+5+6+7+8+9+10+11+12+13+14+15+16+17+18+19+20);

	}

}
