
public class Test006 {

	public static void main(String[] args) {
		// 문자열을 입력받아서 반대로 출력
		// hello -> olleh
		
	}

}
