import java.util.Scanner;

public class Test006 {

	public static void main(String[] args) {
		// 문자열을 입력받아서 반대로 출력
		// hello -> olleh
		Scanner sc = new Scanner(System.in);
		System.out.println("문자열을 입력하세요");
		String str = sc.next();
		for (int i = str.length()-1; i >= 0; i--) {
			System.out.print( str.charAt(i) );
		}
	}
	// 회문 : rotator
	// Test007.java  : 문자열 입력받아서 그 문자열이 회문인지 판단
	// 입력받은 문자열을 꺼꾸로 읽어서 첫번째와 마지막 문자를 같은지 비교해 나가면서
	// 틀린게 있으면 바로 중지.하고 회문이 아니다라고 출력
	//만약 순환문 끝날때까지 중지되지 않으면 회문   
	

}
