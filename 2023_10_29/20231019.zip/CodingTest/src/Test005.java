import java.util.Scanner;

public class Test005 {
// 입력한 문자열의 대소문자를 바꿔서 출력
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("문자열 입력");
		String str = sc.next();	
		
		for (int i = 0; i < str.length(); i++) {  // str.length() 입력한 문자열의 길이
			// 소문자는 대문자 대문자는 소문자로 변경해서 출력
//			System.out.print(); 이런형태로출력
//			ex)  AbcDef --> aBCdEF
			if(Character.isUpperCase( str.charAt(i) ) ) {
				System.out.print( Character.toLowerCase( str.charAt(i) ));
			}else {
				System.out.print( Character.toUpperCase( str.charAt(i) ));
			}
		}
	}

}
