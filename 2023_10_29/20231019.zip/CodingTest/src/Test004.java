import java.util.Scanner;

public class Test004 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("문자열 입력");
		String str = sc.next();
		// Hello
		int count = 0;
		for (int i = 0; i < str.length(); i++) {  // str.length() 입력한 문자열의 길이
//			System.out.println(str.charAt(i));
			if(Character.isUpperCase( str.charAt(i) )) {
				// 대문자
				count++;
			}
		}		
		// 출력
		System.out.println(str + " 대문자의 개수 :" + count);

	}

}
