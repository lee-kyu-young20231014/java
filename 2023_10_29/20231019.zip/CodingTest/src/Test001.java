import java.util.Scanner;

public class Test001 {

	public static void main(String[] args) {		
		// 1. 사용자로부터 문자열을 입력받아서 문자열 변수에 저장하고 출력
		Scanner sc = new Scanner(System.in);
		System.out.println("문자열을 입력하세요 : ");
		String str = sc.next();
		System.out.println(str);
		/////////////////////////////////////////////
		// 정수 a와 b가 있을때 각 수를 입력받아서 아래와 같이 출력
		// a = 10
		// b = 20
		int a = sc.nextInt();
		int b = sc.nextInt();
		System.out.println("a = "+a);
		System.out.println("b = "+b);

	}

}
