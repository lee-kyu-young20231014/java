
public class Test003 {

	public static void main(String[] args) {
		String str = "a";
		System.out.println(str);
		System.out.println(str.toUpperCase()); // 대문자로 변경
		str = "A";
		System.out.println(str);
		System.out.println(str.toLowerCase()); // 소문자로 변경
		// 문자열중에 한개씩 봅아보기
		str = "abcdefg";
		System.out.println(str.charAt(0));  //a
		System.out.println(str.charAt(1)); // b
		// 문자열의 길이
		System.out.println(str.length()); // 7
		// 문자열이 대문인지 소문인지
		
		Character.isUpperCase( str.charAt(0) ); //
		Character.isLowerCase( str.charAt(0) ); //
		
		/////////////////////////////////
		// 주어진 문자열에서 특정 문자를 추출할때는 문자열.charAt(위치)
		// 주어진 문자에서 대소문자여부는 
//		Character.isUpper(문자), Character.isLower(문자)
		// 주어진 문자를 대문자로 변환  Character.toUpper(문자)  그 반대는 소문자
		str = "Hello";
		str.charAt(0); // H
		if( Character.isUpperCase( str.charAt(0) )   ) {
			System.out.println("첫글자는 대문자 입니다.");
		}
		else {
			System.out.println("첫글자는 소문자 입니다.");
		}
		
		// Test004.java 파일을 만들고.. 문자열을 입력받아서. 대문자의 개수를 출력
	}

}
