import java.util.Scanner;

public class Test002 {

	public static void main(String[] args) {
		//문자열 반복출력 
		// 문자열을 입력받고 반복횟수도 입력받아서 해당 횟수만큼 반복출력
		// abc 5
		// abcabcabcabcabc
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		int num = sc.nextInt();
		for (int i = 0; i < num; i++) {
			System.out.print(str);
		}		
	}

}
