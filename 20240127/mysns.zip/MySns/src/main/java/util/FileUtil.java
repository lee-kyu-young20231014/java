package util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileUtil {
	// static method는 클래스의 자원을 사용하지 않는 메소드는 객체로 호출하지 않고
	// 클래스명으로 호출해도 된다. 
	public static void saveImage(String root, String fname, byte[] data) throws IOException {
		root += "/images";
		File f = new File(root);
		if(!f.exists()) f.mkdir();
		
		f = new File(root + "/" + fname);
		FileOutputStream out =  new FileOutputStream(f);
		out.write(data);
		out.close();
	}
}
