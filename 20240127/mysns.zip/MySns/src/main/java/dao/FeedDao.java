package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dto.FeedDto;
import util.ConnectionPool;

public class FeedDao {
	public List<FeedDto> lists(){
		String sql = "select * from feed order by ts desc";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<FeedDto> result = new ArrayList<FeedDto>();
		try {
			conn = ConnectionPool.get();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				int no = rs.getInt("no");
				String id = rs.getString("id");
				String content = rs.getString("content");
				String ts = rs.getTimestamp("ts").toString();
				String image = rs.getString("image");
				
				FeedDto dto = new FeedDto();
				dto.setNo(no);
				dto.setId(id); dto.setContent(content); dto.setTs(ts);
				dto.setImage(image);
				result.add(dto);
			}
			return result;			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return null;
	}
	
	public boolean insert(String id, String content,String image) {
		String sql = "insert into feed(id,content,image) values(?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = ConnectionPool.get();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id); pstmt.setString(2,content);
			pstmt.setString(3, image);
			return pstmt.executeUpdate() == 1;
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return false;
	}

}
