package com.myproject.haksa.utils;

import com.myproject.haksa.member.Student;
import com.myproject.haksa.service.StudentRegisterService;

public class InitSampleData {
	private StudentRegisterService srs;
//	private String[] sNums = { "hbs001", "hbs002", "hbs003", "hbs004", "hbs005"};
	private String[] sNums;
	private String[] sIds = { "rabbit", "hippo", "raccoon", "elephant", "lion" }; 
	private String[] sPws = { "96539", "64875", "15284", "48765", "28661" };
	private String[] sNames = { "agatha", "barbara", "chris", "doris", "elva" };
	private int[] sAges = { 19, 22, 20, 27, 19 }; 
	private char[] sGenders = {'M', 'W', 'W', 'M', 'M' }; 
	private String[] sMajors = { "English Literature",
	  "Korean Language and Literature", "French Language and Literature",
	  "Philosophy", "History", };
	
	// db�� �ʱⰪ���� 5���� �л��� ���
	public InitSampleData(StudentRegisterService srs) {
		super();
		this.srs = srs;
	}

	

	public void setsNums(String[] sNums) {
		this.sNums = sNums;
	}



	public void initData() {		
		for (int i = 0; i < sNums.length; i++) {
			Student s = new Student(sNums[i], sIds[i], sPws[i], sNames[i], 
					sAges[i], sGenders[i], sMajors[i]);
			srs.register(s); 
			
		}
		
		
	}
}
