package com.example.demo.question;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class QuestionService {

	private final QuestioinRepository qr;
	
	public Page<Question> findAll(int page) {
		List<Sort.Order> sorts = new ArrayList<>();		
		sorts.add(Sort.Order.desc("createDate"));		
		
		Pageable pageable = PageRequest.of(page, 10,Sort.by(sorts));
		return qr.findAll(pageable);
	}
	
	public List<Question> findAll() {		
		return qr.findAll();
	}
	public Question getDetail(Integer id) {
		Optional<Question> result = qr.findById(id);
		if(result.isPresent())
			return result.get();
		else
			return null;
	}
	public void create(Question q) {
		q.setCreateDate(LocalDateTime.now());
		qr.save(q);
	}

	public void modify(Question q) {
		q.setModifyDate(LocalDateTime.now());
		qr.save(q);		
	}

	public void delete(Question q) {
		qr.delete(q);		
	}

	public void vote(Question q) {
		qr.save(q);			
	}
	
}













