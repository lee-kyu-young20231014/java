package com.example.demo.answer;

import java.security.Principal;
import java.util.Optional;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.question.Question;
import com.example.demo.question.QuestionService;
import com.example.demo.user.SiteUser;
import com.example.demo.user.SiteUserRepository;
import com.example.demo.user.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

	
@Controller
@RequiredArgsConstructor
public class AnswerController {

	private final AnswerService as;
	private final QuestionService qs;
	private final UserService us;
	private final SiteUserRepository sr;
	
	// vote
		@PreAuthorize("isAuthenticated")
		@GetMapping("/answer/vote/{id}")
		public String answerVote(@PathVariable("id") Integer id, Principal principal) throws Exception 
		{
			Answer a = as.getAnswer(id);
			Optional<SiteUser> su = this.sr.findByusername(principal.getName());
			if(su.isPresent()) {
				
				SiteUser u = su.get();
				Set<SiteUser> users =  a.getVote();
				if(users.contains(u)) {
					users.remove(u);
				}else {
					a.getVote().add(u);				
				}
				 
				this.as.vote(a);			
			}else {
				throw new Exception("사용자 정보를 찾을수 없습니다.");
			}				
			return String.format("redirect:/question/detail/%s", a.getQuestion().getId());
		}
	
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/answer/delete/{id}")
	public String answerDelete(@PathVariable("id") Integer id,Principal principal) throws Exception {
		Answer a =  this.as.getAnswer(id);
		if(!a.getAuthor().getUsername().equals(principal.getName()) ){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"삭제권한이 없습니다.");
		}
		
		this.as.delete(a);
		
		return String.format("redirect:/question/detail/%s", a.getQuestion().getId());
	}
	
	
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/answer/modify/{id}")
	public String answerModify(@PathVariable("id") Integer id,Principal principal, Answer answer) throws Exception {
		Answer a =  this.as.getAnswer(id);
		if(!a.getAuthor().getUsername().equals(principal.getName()) ){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"수정권한이 없습니다.");
		}
		answer.setContent(a.getContent());		
		return "answer_form";
	}
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/answer/modify/{id}")
	public String answerModify(@PathVariable("id") Integer id,Principal principal, 
			@Valid Answer answerForm, BindingResult bindingResult ) throws Exception {
		if(bindingResult.hasErrors())
			return "answer_form";
		
		Answer a =  this.as.getAnswer(id);
		if(!a.getAuthor().getUsername().equals(principal.getName()) ){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"수정권한이 없습니다.");
		}
		a.setContent(answerForm.getContent());
		
		this.as.modify(a);
		return String.format("redirect:/question/detail/%s", a.getQuestion().getId());
	}
	
	
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping("answer/create/{id}")
	public String answerCreate(@PathVariable("id") Integer id, Model model, 
			@Valid Answer answer, BindingResult br,
			Principal principal
			) throws Exception {
		if(br.hasErrors()) {
			Question q =  qs.getDetail(id);
			model.addAttribute("question",q);
			
			model.addAttribute("error","내용은 필수 입니다.");			
			return "question_detail";
		}
		Answer a = new Answer();
		a.setQuestion(qs.getDetail(id));
		a.setContent(answer.getContent());
		SiteUser user =  us.getUser( principal.getName());
		
		a.setAuthor(user);
		as.answerCreate(a);		
		return String.format("redirect:/question/detail/%s", id);
	}
	
}
