package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class MainController {
	@GetMapping("/")
	@ResponseBody
	public String getMethodName() {
		return "<h1>안녕하세요 스프링 부트 입니다.<h1/>";
	}
	
}
