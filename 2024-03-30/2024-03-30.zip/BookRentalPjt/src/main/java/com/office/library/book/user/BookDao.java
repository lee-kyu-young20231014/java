package com.office.library.book.user;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.office.library.book.BookVo;
import com.office.library.book.RentalBookVo;

@Repository("user.BookDao")
public class BookDao {
	@Autowired
	SqlSessionTemplate sst;
	
	public List<BookVo> searchBookConfirm(String b_name) {
		b_name = "%"+b_name+"%";
		return sst.selectList("adbminbook.searchBookConfirm", b_name);
	}

	public BookVo bookDetail(int b_no) {		
		return sst.selectOne("adbminbook.bookDetail", b_no);
	}

	public int rentalBookConfirm(int b_no) {		
		return sst.update("userbook.rentalBookConfirm", b_no);
	}

	public int insertrental(RentalBookVo rentalBookVo) {		
		return sst.update("rentalbook.insertrental", rentalBookVo);
	}

	public List<RentalBookVo> enterBookshelf(int u_m_no) {		
		return sst.selectList("rentalbook.enterBookshelf", u_m_no);
	}	
}
