package com.office.library.book.admin;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.office.library.book.BookVo;
import com.office.library.book.RentalBookVo;

@Repository
public class BookDao {

	@Autowired
	SqlSessionTemplate sst;
	
	public boolean isISBN(String b_isbn) {
		int result = sst.selectOne("adbminbook.isISBN", b_isbn);
		return result > 0;
	}

	public int insertBook(BookVo bookVo) {		
		return sst.insert("adbminbook.insertBook", bookVo);
	}

	public List<BookVo> searchBookConfirm(String b_name) {	
		b_name = "%"+b_name+"%";
		return sst.selectList("adbminbook.searchBookConfirm", b_name);
	}

	public BookVo bookDetail(int b_no) {		
		return sst.selectOne("adbminbook.bookDetail", b_no);
	}

	public BookVo modifyBookForm(int b_no) {		
		return sst.selectOne("adbminbook.bookDetail", b_no);
	}

	public int modifyBookConfirm(BookVo bookVo) {		
		return sst.update("adbminbook.modifyBookConfirm", bookVo);
	}

	public int deleteBookConfirm(int b_no) {		
		return sst.delete("adbminbook.deleteBookConfirm", b_no);
	}

	public List<RentalBookVo> getRentalBooks() {		
		return sst.selectList("adbminbook.getRentalBooks");
	}

	public int returnBookConfirmBook(RentalBookVo vo) {		
		return sst.update("adbminbook.returnBookConfirmBook", vo);
	}

	public int returnBookConfirmRentalBook(RentalBookVo vo) {
		return sst.update("adbminbook.returnBookConfirmRentalBook",vo);
		
	}

}
