package com.office.library.book.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.office.library.book.BookVo;
import com.office.library.book.RentalBookVo;

@Service
public class BookService {
	final static public int BOOK_ISBN_ALREADY_EXIST = 0; // �̹� ��ϵ� ����
	final static public int BOOK_REGISTER_SUCCESS = 1; // �ű� ���� ��� ����
	final static public int BOOK_REGISTER_FAIL = -1; // �ű� ���� ��� ����

	@Autowired
	BookDao bookDao;

	public int registerBookConfirm(BookVo bookVo) {
		boolean isISBN = bookDao.isISBN(bookVo.getB_isbn());

		if (!isISBN) {
			int result = bookDao.insertBook(bookVo);

			if (result > 0)
				return BOOK_REGISTER_SUCCESS;

			else
				return BOOK_REGISTER_FAIL;

		} else {
			return BOOK_ISBN_ALREADY_EXIST;

		}		
	}

	public List<BookVo> searchBookConfirm(String b_name) {		
		return bookDao.searchBookConfirm(b_name);
	}

	public BookVo bookDetail(int b_no) {		
		return bookDao.bookDetail(b_no);
	}

	public BookVo modifyBookForm(int b_no) {		
		return bookDao.modifyBookForm(b_no);
	}

	public int modifyBookConfirm(BookVo bookVo) {		
		return bookDao.modifyBookConfirm(bookVo);
	}

	public int deleteBookConfirm(int b_no) {		
		return bookDao.deleteBookConfirm(b_no);
	}

	public List<RentalBookVo> getRentalBooks() {		
		return bookDao.getRentalBooks();
	}

	public int returnBookConfirm(RentalBookVo vo) {
		// tbl_book    b_rantal_able  1
		// tbl_rental_book  rb_end_date = now()
		try {
			int result = bookDao.returnBookConfirmBook(vo);
			if(result > 0)
				result = bookDao.returnBookConfirmRentalBook(vo);			
			return result;
		} catch (Exception e) {}
		return 0;
	}

}
