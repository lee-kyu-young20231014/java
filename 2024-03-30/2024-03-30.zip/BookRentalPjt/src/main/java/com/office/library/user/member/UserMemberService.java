package com.office.library.user.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.office.library.admin.member.AdminMemberVo;
import com.office.library.util.PasswordGenerator;

@Service
public class UserMemberService {
	
	@Autowired
	UserMemberDao umd;
	
	public int createAccountConfirm(UserMemberVo vo) {		
		return umd.createAccountConfirm(vo);
	}

	public UserMemberVo loginConfirm(UserMemberVo vo) {		
		return umd.loginConfirm(vo);
	}

	public UserMemberVo modifyAccountConfirm(UserMemberVo vo) {
		// modify
		int result = umd.modifyAccountConfirm(vo);
		
		if(result > 0) {
		// select
			return umd.selectBym_no(vo.getU_m_no());
		}
		return null;
	}
@Autowired
PasswordGenerator passwordGenerator;

	public int findPasswordConfirm(UserMemberVo vo) {
		UserMemberVo findVo =  umd.findPasswordConfirm(vo);
		
		int result = 0;
		if(findVo!=null) {
			String newPassowrd = passwordGenerator.generatePassword(10);
			result = umd.updatePassword(findVo.getU_m_id(), newPassowrd);
			if(result > 0) {
				passwordGenerator.sendNewPasswordByMail(findVo.getU_m_mail(), newPassowrd);
			}			
		}
		return 0;
	}

}
