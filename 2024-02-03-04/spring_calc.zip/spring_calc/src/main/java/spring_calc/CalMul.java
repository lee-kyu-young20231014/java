package spring_calc;
public class CalMul implements ICalculator {
    public int doOperation(int firstNum, int secondNum) {
        return firstNum * secondNum;
    }
}