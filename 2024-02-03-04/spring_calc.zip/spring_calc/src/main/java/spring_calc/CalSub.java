package spring_calc;
public class CalSub implements ICalculator {
    public int doOperation(int firstNum, int secondNum) {
        return firstNum - secondNum;
    }
}