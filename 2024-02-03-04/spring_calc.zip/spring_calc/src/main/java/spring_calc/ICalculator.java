package spring_calc;
public interface ICalculator {

    public int doOperation(int firstNum, int secondNum);

}