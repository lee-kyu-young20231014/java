package spring_calc;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {
    public static void main(String[] args) {

    	// xml형태로된 Ioc 컨테이너를 사용 할 수 있도록 설정
    	GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationContext.xml");
    
    	// xml에 bean태그로 정의되어 있는 bean객체를 가져온다.
    	// new연산자로 객체를 직접생성하지 않고 스프링에서 xml파일에 있는 내용을 먼저 읽고 해당하는 객체를 미리 만들어 논걸 사용한다
    	//  스프링의 DI ( IOC)
    	CalAssembler calAssembler = ctx.getBean("calAssembler", CalAssembler.class);
    	calAssembler.assemble();
        
	ctx.close();
        
    }
}