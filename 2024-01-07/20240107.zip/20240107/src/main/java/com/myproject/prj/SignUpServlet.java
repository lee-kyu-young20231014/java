package com.myproject.prj;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SignUpServlet
 */
@WebServlet("/signup")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		// 1. 아이디를 검사해서 중복인지 확인
		String id = request.getParameter("id");
		// member 객체에서 회원이 있는지 조회
		Member member =  Member.getInstance();
		String html = "";
		if(member.isMember(id)) {
			html = "중복 되었습니다.";
		}else {
			String psw = request.getParameter("psw");
			String name = request.getParameter("name");
			// 회원저장
			Map<String, String> m = new HashMap<String, String>();
			m.put("id", id); m.put("psw", psw); m.put("name", name);
			member.addMember(m);
			html = "회원가입 완료";
		}
		
		response.setContentType("text/html; charset=UTF-8"); // 서블릿에서 한글깨짐 방지		
		response.getWriter().append(html);
	}

}



