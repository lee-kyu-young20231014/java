package com.myproject.prj;
/**
 * 회원목록 저장 및 관리
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 싱글톤 : 객체를 여러개 만드는게 아니라 한개만 가지고 사용 하는 기법
 * new 연산자로 객체생성 금지
 * 객체는 클래스에서 최초 한번 만들고 외부에서 계속 같은 객체를 사용하도록 제공
 */
public class Member {
	private static Member instance = null;
	private List< Map<String, String> > members = new ArrayList<Map<String,String>>();	
	private Member() {}  // 생성자 사용 금지
	
	// 최초 객체생성하고 제공(여러번 생성 금지)
	public static Member getInstance() {
		if(instance == null)
			instance = new Member();
		return instance;
	}
	
	
	// 아이디로 회원 조회
	public boolean isMember(String id) {
		for(Map<String, String> member : members) {
			if(id.equals( member.get("id") ) ) {
				return true;
			}
		}
		return false;
	}
	
	// 회원목록에 회원을 저장
	public void addMember(Map<String, String> member) {
		members.add(member);
	}
	// 회원조회 - 로그인
	public Map<String, String> findMember(String id, String password){
		for(Map<String, String> member : members) {
			if ( id.equals( member.get("id")) 
					&& password.equals(member.get("psw")) )
				return member;
		}
		return null;
	}
	
}
