package com.project.test.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MemberController {

	@Autowired
	MemberService memberService;
	
	
	@RequestMapping("/signUp")
	public String signUp() {
		
		return "sign_up";
	}
	
	@RequestMapping("/signUpConfirm")
	public String signUpConfirm(MemberVo memberVo) {
		System.out.println("[MemberController] signUpConfirm()");
		
		memberService.signUpConfirm(memberVo);
		
		return "sign_up_ok";
		
	}
	
	@RequestMapping("/signIn")
	public String signIn()  {
		
		return "sign_in";
	}
	
	@RequestMapping("/signInConfirm") 
	public String signInConfirm(MemberVo memberVo) {
		System.out.println("[MemberController] signInConfirm()");
		
		MemberVo signInedMember = memberService.signInConfirm(memberVo); 
		
		if (signInedMember != null)		
			return "sign_in_ok";
		else					
			return "sign_in_ng";
		
	}
	
}
