package com.office.library.user.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserMemberService {
	
	@Autowired
	UserMemberDao umd;
	
	public int createAccountConfirm(UserMemberVo vo) {		
		return umd.createAccountConfirm(vo);
	}

	public UserMemberVo loginConfirm(UserMemberVo vo) {		
		return umd.loginConfirm(vo);
	}

	public UserMemberVo modifyAccountConfirm(UserMemberVo vo) {
		// modify
		int result = umd.modifyAccountConfirm(vo);
		
		if(result > 0) {
		// select
			return umd.selectBym_no(vo.getU_m_no());
		}
		return null;
	}

}
