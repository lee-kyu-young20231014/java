package com.office.library.user.member;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user/member")
public class UserMemberController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	UserMemberService ums;
	
	@GetMapping("/createAccountForm")
	public String createAccountForm(){
		return "user/member/create_account_form";
	}
	
	@PostMapping("/createAccountConfirm")
	public String createAccountConfirm(UserMemberVo vo) {
		String nextPage = "user/member/create_account_ok";
		int result = ums.createAccountConfirm(vo);
		if (result <= 0)
			nextPage = "user/member/create_account_ng";
		return nextPage;
	}
	
	@GetMapping("loginForm")
	public String loginForm() {
		return "user/member/login_form";
	}
	
	@PostMapping("loginConfirm")
	public String loginConfirm(UserMemberVo vo,HttpSession session) 
	{
		String nextPage = "user/member/login_ok";
		UserMemberVo loginedUserMemberVo =  ums.loginConfirm(vo);
		if(loginedUserMemberVo != null) {
			session.setAttribute("loginedUserMemberVo", loginedUserMemberVo);
		}
		else
			nextPage = "user/member/login_ng";
		
		return nextPage;
		
	}
	
	@GetMapping("modifyAccountForm")
	public String modifyAccountForm(Model model, HttpSession session) {
		String nextPage = "user/member/modify_account_form";
		
		UserMemberVo loginedUserMemberVo =  
				(UserMemberVo) session.getAttribute("loginedUserMemberVo");
		if(loginedUserMemberVo != null) {
			model.addAttribute("loginedUserMemberVo", loginedUserMemberVo);
		}else {
			nextPage = "redirect:/user/member/loginForm";
		}
		
		return nextPage;
	}
	
	@PostMapping("modifyAccountConfirm")
	public String modifyAccountConfirm(UserMemberVo vo,HttpSession session) 
	{
		String nextPage = "user/member/modify_account_ok";
		UserMemberVo loginedUserMemberVo =  ums.modifyAccountConfirm(vo);
		if( loginedUserMemberVo != null) {
			session.setAttribute("loginedUserMemberVo", loginedUserMemberVo);			
		}else {
			nextPage = "user/member/modify_account_ng";
		}
		return nextPage;
	}
}
