package com.office.library.user.member;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

@Repository
public class UserMemberDao {

	@Autowired
	SqlSessionTemplate sst;
	
	@Autowired
	BCryptPasswordEncoder bpe;
	public int createAccountConfirm(UserMemberVo vo) {
		vo.setU_m_pw(   bpe.encode(vo.getU_m_pw())  );
		return sst.insert("userbook.createAccountConfirm", vo);
	}
	public UserMemberVo loginConfirm(UserMemberVo vo) {
		UserMemberVo selectVo = sst.selectOne("userbook.loginConfirm", vo);
		return bpe.matches(vo.getU_m_pw(), selectVo.getU_m_pw())? selectVo : null;
	}
	
	
	public int modifyAccountConfirm(UserMemberVo vo) {		
		return sst.update("userMember.modifyAccountConfirm", vo);
	}	
	
	public UserMemberVo selectBym_no(int u_m_no) {		
		return sst.selectOne("userMember.selectBym_no", u_m_no);
	}

}
