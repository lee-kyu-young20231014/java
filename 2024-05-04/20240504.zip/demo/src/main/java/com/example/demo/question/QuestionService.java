package com.example.demo.question;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.example.demo.answer.Answer;
import com.example.demo.user.SiteUser;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class QuestionService {

	private final QuestioinRepository qr;	

	
	
	
	public Page<Question> findAll(int page) {
		List<Sort.Order> sorts = new ArrayList<>();		
		sorts.add(Sort.Order.desc("createDate"));		
		
		Pageable pageable = PageRequest.of(page, 10,Sort.by(sorts));
		return qr.findAll(pageable);
	}
	
	public List<Question> findAll() {		
		return qr.findAll();
	}
	public Question getDetail(Integer id) {
		Optional<Question> result = qr.findById(id);
		if(result.isPresent())
			return result.get();
		else
			return null;
	}
	public void create(Question q) {
		q.setCreateDate(LocalDateTime.now());
		qr.save(q);
	}

	public void modify(Question q) {
		q.setModifyDate(LocalDateTime.now());
		qr.save(q);		
	}

	public void delete(Question q) {
		qr.delete(q);		
	}

	public void vote(Question q) {
		qr.save(q);			
	}
	
	
	public Page<Question> findAll(int page,String keyword) {
		List<Sort.Order> sorts = new ArrayList<>();		
		sorts.add(Sort.Order.desc("createDate"));		
		
		Pageable pageable = PageRequest.of(page, 10,Sort.by(sorts));
		
//		Specification<Question> spec = search(keyword);
//		return qr.findAll(spec, pageable);
		return qr.findAllByKeyword(keyword, pageable);
	} 
	
	
	private Specification<Question> search(String keyword){
		
		return new Specification<Question>() {			
			
			private static final long serialVersionUID = 1L;

			@Override
			public Predicate toPredicate(Root<Question> q, CriteriaQuery<?> query, CriteriaBuilder cb) {
				query.distinct(true);
				Join<Question, SiteUser> u1 = q.join("author", JoinType.LEFT);
				Join<Question, Answer> a = q.join("answerList",JoinType.LEFT);
				Join<Answer, SiteUser> u2 = a.join("author",JoinType.LEFT);				 
				return cb.or(
						cb.like(q.get("subject"), "%" + keyword + "%"),  // 제목
						cb.like(q.get("content"), "%" + keyword + "%"),  // 내용
						cb.like(u1.get("username"), "%" + keyword + "%"),  // 질문 작성자
						cb.like(a.get("content"), "%" + keyword + "%"),  // 답변 내용
						cb.like(u2.get("username"), "%" + keyword + "%")  // 답변 작성자
						);
			}
		};
	}
	
}













