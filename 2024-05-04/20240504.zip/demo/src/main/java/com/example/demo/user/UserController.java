package com.example.demo.user;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestParam;




@RequiredArgsConstructor
@Controller
public class UserController {
	private final UserService service;
	
	@GetMapping("/user/signup")
	public String signup(UserCreateForm form) {
		return "signup_form";
	}
	
	@PostMapping("/user/signup")
	public String signup(@Valid UserCreateForm form, BindingResult result) {
		if(result.hasErrors()) {
			return "signup_form";
		}
		
		if( !form.getPassword1().equals(form.getPassword2()) ) 
		{
			result.rejectValue("password2", "passwordInCorect","2개의 패스워드가 일치하지 않습니다.");
			return "signup_form";
		}
		
		try {
			service.create(form.getUsername(), form.getEmail(), form.getPassword1());			
		}
		catch(DataIntegrityViolationException e) {
			e.printStackTrace();
			result.reject("signupFailed", "이미등록된 사용자 입니다.");
			return "signup_form";
		}
		catch (Exception e) {
			e.printStackTrace();
			result.reject("signupFailed",  e.getMessage());
			return "signup_form";
		}
		
		return "redirect:/";
	}
	
	@GetMapping("/user/login")
	public String login() {
		return "login_form";
	}
}
