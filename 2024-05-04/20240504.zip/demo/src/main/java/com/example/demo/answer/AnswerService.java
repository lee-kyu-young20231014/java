package com.example.demo.answer;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AnswerService {
	private final AnswerRepository ar;

	public void answerCreate(Answer answer) {
		answer.setCreateDate(LocalDateTime.now());
		ar.save(answer);		
	}

	public Answer getAnswer(Integer id) throws Exception {
		Optional<Answer> answer =  ar.findById(id);
		if(answer.isPresent())
			return answer.get();
		else
			throw new Exception("answer not found"); 
	}

	public void delete(Answer a) {
		this.ar.delete(a);		
	}

	public void modify(Answer a) {
		a.setModifyDate(LocalDateTime.now());
		this.ar.save(a);		
	}

	public void vote(Answer a) {
		ar.save(a);		
	}

}
















