package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.json.JSONObject;

import dto.UserDto;
import util.ConnectionPool;

public class UserDao {
	
	public boolean login(String id, String password) {
		String sql = "select * from user where id = ? and password = ?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = ConnectionPool.get();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			return rs.next();
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return false;
	}
	
	public boolean delete(String id) {
		String sql = "delete from user where id = ?";
		
		Connection conn = null;
		PreparedStatement pstmt = null;		
		try {
			conn = ConnectionPool.get();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			return pstmt.executeUpdate() == 1;
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {				
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return false;
	}
	// 회원가입용
	// id 존재여부만 조회
	public boolean exist(UserDto dto) {
		String sql = "select * from user where id = ?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = ConnectionPool.get();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			rs = pstmt.executeQuery();
			rs.next();
			dto.setPassword( rs.getString("password") );
			return true;			
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return false;
	}
	// 로그인용 회원존재유무 확인
	// 아이디가 없으면 1
	// 아이디는 맞는데 패스워드가 틀리면 2
	// 아이디와 패스워드 둘다 맞으면 3
	public int exist(String jsonstr) {
		JSONObject jsonObj =  new JSONObject(jsonstr);
		UserDto dto = new UserDto();
		dto.setId(jsonObj.getString("id"));
		
		if(exist(dto)) { // id가 존재하면  dto에는 DB에 있는 패스워드가 저장되어 있다			
			String password = jsonObj.getString("password");
			if(password.equals(dto.getPassword()))
				return 3;
			else
				return 2;			
		}else { // id가 존재하지 않으면
			return 1;
		}		
	}
	
	public boolean insert(String jsonstr) {
		// insert 쿼리 만들기
		String sql = "insert into user(id,password,name) values( ?,?,? )" ;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			JSONObject obj =  new JSONObject(jsonstr);
			
			conn = ConnectionPool.get();
			// 3. 커넥션 객체를 통해 스테이트먼트 객체 생성
			pstmt =  conn.prepareStatement(sql);			
			pstmt.setString(1, obj.getString("id"));
			pstmt.setString(2, obj.getString("password"));
			pstmt.setString(3, obj.getString("name"));
			// insert 쿼리를 스테이트먼트 객체를 통해 실행
			return pstmt.executeUpdate() == 1;
		}
		catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}
}
