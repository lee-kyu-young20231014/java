package com.office.library.book.user;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.office.library.book.BookVo;
import com.office.library.book.RentalBookVo;
import com.office.library.user.member.UserMemberVo;

@Controller("user.BookController")
@RequestMapping("/book/user/")
public class BookController {
	@Autowired
	BookService bookService;
	
	@GetMapping("searchBookConfirm")
	public String searchBookConfirm(Model model, 
			@RequestParam("b_name") String b_name) {
		String nextPage = "user/book/search_book";
		List<BookVo> bookVos = bookService.searchBookConfirm(b_name);
		model.addAttribute("bookVos", bookVos);
		return nextPage;
	}
	
	@GetMapping("bookDetail")
	public String bookDetail(Model model,
			@RequestParam("b_no") int b_no) 
	{
		BookVo bookVo = bookService.bookDetail(b_no);
		model.addAttribute("bookVo", bookVo);
		return "user/book/book_detail";
	}
	
	@GetMapping("rentalBookConfirm")
	public String rentalBookConfirm(
			@RequestParam("b_no") int b_no,
			HttpSession session
			) {
		
		UserMemberVo loginedMeberVo 
			= (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		if(loginedMeberVo == null)
			return "redirect:/user/member/loginForm";
		
		RentalBookVo rentalBookVo = new RentalBookVo();
		rentalBookVo.setB_no(b_no);
		rentalBookVo.setU_m_no(loginedMeberVo.getU_m_no());
		
		int result  = bookService.rentalBookConfirm(rentalBookVo);
		if(result <=0)
			return "user/book/rental_book_ng"; 
		
		return "user/book/rental_book_ok";
	}
	
	@GetMapping("enterBookshelf")
	public String enterBookshelf(Model model,HttpSession session) {
		String nextPage = "user/book/bookshelf";
		
		UserMemberVo vo 
		=  (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		
		List<RentalBookVo> rentalBookVos 
		= bookService.enterBookshelf(vo.getU_m_no());
		
		model.addAttribute("rentalBookVos", rentalBookVos);
		return nextPage;
	}
	
}
