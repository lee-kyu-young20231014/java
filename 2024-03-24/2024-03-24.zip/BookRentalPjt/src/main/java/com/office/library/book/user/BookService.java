package com.office.library.book.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.office.library.book.BookVo;
import com.office.library.book.RentalBookVo;

@Service("user.BookService")
public class BookService {
	@Autowired
	BookDao bookDao;
	
	public List<BookVo> searchBookConfirm(String b_name) {		
		return bookDao.searchBookConfirm(b_name);
	}

	public BookVo bookDetail(int b_no) {		
		return bookDao.bookDetail(b_no);
	}

	public int rentalBookConfirm(RentalBookVo rentalBookVo) {
		int result = bookDao.insertrental(rentalBookVo);		
		if(result <= 0)			
			return -1;
		return bookDao.rentalBookConfirm(rentalBookVo.getB_no());
	}

	public List<RentalBookVo> enterBookshelf(int u_m_no) {
		return bookDao.enterBookshelf(u_m_no);
	}

}
