package com.office.library.book;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RentalBookVo {	        
	int b_no  ;       
	int u_m_no ;      
	String rb_start_date;
	String rb_end_date  ;
	String rb_reg_date  ;
	String rb_mod_date  ;
}
