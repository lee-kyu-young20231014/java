package com.office.library.admin.member;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class AdminMemberDao {	
	
	
	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate; 
	
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	
	
	public int insertAdminAccount(AdminMemberVo adminMemberVo) {
		adminMemberVo.setA_m_pw(bCryptPasswordEncoder.encode(adminMemberVo.getA_m_pw()) );
		
		return sqlSessionTemplate.insert("adminMember.adminMemberInsert",adminMemberVo);
	}

	public boolean isAdminMember(String a_m_id) {		
		return sqlSessionTemplate.selectOne("adminMember.selectAdmin", a_m_id) != null;
	}

	public AdminMemberVo selectAdmin(AdminMemberVo adminMemberVo) {
		AdminMemberVo vo = sqlSessionTemplate.selectOne("adminMember.selectAdmin", adminMemberVo.getA_m_id());
		
		if(vo != null &&
				bCryptPasswordEncoder.matches(adminMemberVo.getA_m_pw(), vo.getA_m_pw())
				) 
			return vo;
		else
			return null;
	}
	

	public List<AdminMemberVo> selectAdmins() {		
		return sqlSessionTemplate.selectList("adminMember.selectAdmins");
	}

	public void setAdminApproval(int a_m_no) {
		sqlSessionTemplate.update("adminMember.setAdminApproval", a_m_no);		
	}

	public int modifyAccountConfirm(AdminMemberVo adminMemberVo) {
		return sqlSessionTemplate.update("adminMember.modifyAccountConfirm", adminMemberVo);		
	}

	public AdminMemberVo findPasswordConfirm(AdminMemberVo adminMemberVo) {		
//		Map<String, String> map = new HashMap<String, String>();
//		map.put("a_m_id", adminMemberVo.getA_m_id());
//		map.put("a_m_name", adminMemberVo.getA_m_name());
//		map.put("a_m_mail", adminMemberVo.getA_m_mail());
		return sqlSessionTemplate.selectOne("adminMember.findPasswordConfirm", adminMemberVo);
	}

	public int updatePassword(String a_m_id, String newPassowrd) {
		newPassowrd = bCryptPasswordEncoder.encode(newPassowrd);
		Map<String, String> map = new HashMap<String, String>();
		map.put("a_m_id", a_m_id); map.put("newPassowrd", newPassowrd);
		return sqlSessionTemplate.update("adminMember.updatePassword", map);
	}
	
	

}
