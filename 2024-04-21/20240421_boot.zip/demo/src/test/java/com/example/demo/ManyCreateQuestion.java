package com.example.demo;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.question.QuestioinRepository;
import com.example.demo.question.Question;

@SpringBootTest
public class ManyCreateQuestion {
	@Autowired
	QuestioinRepository qr;
	
	@Test
	public void manyCreateQuestion() {
		for (int i = 0; i < 15; i++) {
			Question q = new Question();
			q.setSubject(String.format("테스트 데이터 제목 %d", i+1));
			q.setContent(String.format("테스트 데이터 내용 %d", i+1));
			q.setCreateDate(LocalDateTime.now());
			qr.save(q);
		}
	}
		
}
