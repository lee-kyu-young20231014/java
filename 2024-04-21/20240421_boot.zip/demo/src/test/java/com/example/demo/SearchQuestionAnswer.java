package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.answer.Answer;
import com.example.demo.answer.AnswerRepository;
import com.example.demo.question.QuestioinRepository;
import com.example.demo.question.Question;

import jakarta.transaction.Transactional;

@SpringBootTest
public class SearchQuestionAnswer {
	@Autowired
	QuestioinRepository qr;
	
	@Autowired
	AnswerRepository ar;	
	
	@Test
	@Transactional   // 단위테스트 할때 jap과련 명령어를 실행하고 나면 DB 세션이 끊어지는것을 방지
	void searchQA() {
		// question 객체 찾고  id = 2
		// question 에 답변이 있으면 답변들 출력
		Optional<Question> oq = qr.findById(2);  // DB세션이 종료
		assertTrue(oq.isPresent());
		Question q = oq.get();
		List<Answer> alists =  q.getAnswerList(); // DB세션이 종료되었으므로 에러가 난다(단위테스트에서만)
		assertEquals(2, alists.size());
	}
}
