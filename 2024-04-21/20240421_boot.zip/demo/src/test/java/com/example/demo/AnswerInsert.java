package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.answer.Answer;
import com.example.demo.answer.AnswerRepository;
import com.example.demo.question.QuestioinRepository;
import com.example.demo.question.Question;

@SpringBootTest
public class AnswerInsert {

	@Autowired
	AnswerRepository ar;
	
	@Autowired
	QuestioinRepository qr;
	
	@Test
	void createAnswer1() {	
		Answer answer = new Answer();
		answer.setContent("질문에대한 답변입니다 1.");
		answer.setCreateDate(LocalDateTime.now());
		
		Optional<Question> oq =  qr.findById(2);
		assertTrue(oq.isPresent());
		answer.setQuestion(oq.get());
		ar.save(answer);
	}
	
	@Test
	void createAnswer2() {	
		Answer answer = new Answer();
		answer.setContent("질문에대한 답변입니다 2.");
		answer.setCreateDate(LocalDateTime.now());
		
		Optional<Question> oq =  qr.findById(2);
		assertTrue(oq.isPresent());
		answer.setQuestion(oq.get());
		ar.save(answer);
	}
	
}
