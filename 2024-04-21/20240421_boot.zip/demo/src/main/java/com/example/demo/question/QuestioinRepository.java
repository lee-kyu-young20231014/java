package com.example.demo.question;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuestioinRepository extends JpaRepository<Question, Integer>{	
	Page<Question> findAll(Pageable pagealbe);
}
