package com.example.demo.answer;

import java.security.Principal;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.question.Question;
import com.example.demo.question.QuestionService;
import com.example.demo.user.SiteUser;
import com.example.demo.user.UserService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

	
@Controller
@RequiredArgsConstructor
public class AnswerController {

	private final AnswerService as;
	private final QuestionService qs;
	private final UserService us;
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping("answer/create/{id}")
	public String answerCreate(@PathVariable("id") Integer id, Model model, 
			@Valid Answer answer, BindingResult br,
			Principal principal
			) throws Exception {
		if(br.hasErrors()) {
			Question q =  qs.getDetail(id);
			model.addAttribute("question",q);
			
			model.addAttribute("error","내용은 필수 입니다.");			
			return "question_detail";
		}
		Answer a = new Answer();
		a.setQuestion(qs.getDetail(id));
		a.setContent(answer.getContent());
		SiteUser user =  us.getUser( principal.getName());
		
		a.setAuthor(user);
		as.answerCreate(a);		
		return String.format("redirect:/question/detail/%s", id);
	}
	
}
