package com.example.demo.user;

import java.util.Optional;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class UserService {
	private final SiteUserRepository repository;
	private final BCryptPasswordEncoder pswEncoder;
	
	public SiteUser create(String username, String email, String password) {
		SiteUser user = new SiteUser();
		user.setUsername(username);
		user.setEmail(email);		
		user.setPassword(pswEncoder.encode(password));
		repository.save(user);
		return user;
	}

	public SiteUser getUser(String name) throws Exception {
		Optional<SiteUser> user =  repository.findByusername(name);
		if(user.isPresent())
			return user.get();
		else
			throw new Exception("유저를 찾을수 없습니다.");
	}
}
