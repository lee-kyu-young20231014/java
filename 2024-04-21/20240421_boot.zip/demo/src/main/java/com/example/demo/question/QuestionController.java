package com.example.demo.question;

import java.security.Principal;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.answer.Answer;
import com.example.demo.user.SiteUser;
import com.example.demo.user.SiteUserRepository;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;




@Controller
@RequiredArgsConstructor
public class QuestionController {

//	@Autowired
//	private final QuestioinRepository qr;  // @RequiredArgsConstructor 생성자를 통한 자동주입
	private final QuestionService qs;
	private final SiteUserRepository sr;
	
	@GetMapping("/question/list")
//	@ResponseBody
	public String questionLists(Model model, 
			@RequestParam(value = "page",defaultValue="0") int page) {
		
		Page<Question> paging = qs.findAll(page);
		model.addAttribute("paging", paging);
		
		return "question_list";
	}
	@GetMapping("/question/detail/{id}")
	public String detail(Model model,@PathVariable("id") Integer id,
			Answer answer)
	{
		// 서비스 호출
		// 결과 받아서 detail 로 전달
		Question q =  qs.getDetail(id);
		model.addAttribute("question",q);
		return "question_detail";
	}
	
	@GetMapping("/question/create")
	public String create_form(Question question) {
		return "question_form";
	}
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/question/create")
	public String create(@Valid Question q, BindingResult br,
			Principal principal ) throws Exception {
		if(br.hasErrors()) {
			return "question_form";
		}
		Optional<SiteUser> user = sr.findByusername( principal.getName() );
		if(!user.isPresent())
			throw new Exception("사용자 정보를 찾을수 없습니다.");
		q.setAuthor(user.get());
		qs.create(q);		
		return String.format("redirect:/question/list");
	}
}
