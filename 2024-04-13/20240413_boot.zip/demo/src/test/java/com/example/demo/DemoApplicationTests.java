package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.question.QuestioinRepository;
import com.example.demo.question.Question;
/**
 * 서버가 구동중이면 에러가 발생한다.. 서버중지후 단위테스트 할것
 */
@SpringBootTest
class DemoApplicationTests {
	@Autowired
	private QuestioinRepository questionRepository;

	@Test
	void contextLoads() {
		//질문 객체를 만들어서
		// questionRepository를 이용해서 저장한다. --- DAO insert와 동일
		
		Question q1 = new Question();
		q1.setSubject("첫번째 질문");
		q1.setContent("질문의 내용");
		q1.setCreateDate(LocalDateTime.now());
		questionRepository.save(q1);
		
		Question q2 = new Question();
		q2.setSubject("두번째 질문");
		q2.setContent("질문의 내용");
		q2.setCreateDate(LocalDateTime.now());
		questionRepository.save(q2);
	}
	
	@Test
	/**
	 * 질문 객체를 하나 가져와서 제목을 변경하고 업데이트 한다.
	 */
	void QeustionTitleModify() {
		Optional<Question> oq =  questionRepository.findById(1);
		assertTrue(oq.isPresent());  // oq의 객체가 널이아니면
		Question q =  oq.get();
		q.setSubject("수정된 제목");
		questionRepository.save(q);
	}
	

}
