package com.example.demo.answer;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.question.QuestionService;

import lombok.RequiredArgsConstructor;


@Controller
@RequiredArgsConstructor
public class AnswerController {

	private final AnswerService as;
	private final QuestionService qs;
	
	@PostMapping("answer/create/{id}")
	public String answerCreate(@PathVariable("id") Integer id, Answer answer) {		
		Answer a = new Answer();
		a.setQuestion(qs.getDetail(id));
		a.setContent(answer.getContent());
		as.answerCreate(a);		
		return String.format("redirect:/question/detail/%s", id);
	}
	
}
