package com.example.demo.answer;

import java.time.LocalDateTime;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AnswerService {
	private final AnswerRepository ar;

	public void answerCreate(Answer answer) {
		answer.setCreateDate(LocalDateTime.now());
		ar.save(answer);		
	}

}
