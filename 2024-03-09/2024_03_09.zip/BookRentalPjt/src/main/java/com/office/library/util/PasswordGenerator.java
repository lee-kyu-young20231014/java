package com.office.library.util;

import java.security.SecureRandom;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;

@Component
public class PasswordGenerator {
	@Autowired
	JavaMailSenderImpl javaMailSenderImpl;
	
	private static final String CHAR_LOWER = "abcdefghijklmnopqrstuvwxyz";
    private static final String CHAR_UPPER = CHAR_LOWER.toUpperCase();
    private static final String NUMBER = "0123456789";
    private static final String SPECIAL_CHARACTERS = "!@#$%&*_+-=?";

    private static final String PASSWORD_ALLOW_BASE = CHAR_LOWER + CHAR_UPPER + NUMBER + SPECIAL_CHARACTERS;
    
    private static SecureRandom random = new SecureRandom();
    
    public static void main(String[] args) {
        System.out.println(new PasswordGenerator().generatePassword(10)); // �ӽ� ��й�ȣ�� ���̸� ���⿡ �����ϼ���
    }

    public  String generatePassword(int length) {
        if (length < 4) {
            throw new IllegalArgumentException("Password length must be at least 4 characters.");
        }
        
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length - 3; i++) {
            int rndCharAt = random.nextInt(PASSWORD_ALLOW_BASE.length());
            char rndChar = PASSWORD_ALLOW_BASE.charAt(rndCharAt);
            sb.append(rndChar);
        }

        // Append one uppercase letter, one lowercase letter, one digit, and one special character
        sb.append(CHAR_LOWER.charAt(random.nextInt(CHAR_LOWER.length())));
        sb.append(CHAR_UPPER.charAt(random.nextInt(CHAR_UPPER.length())));
        sb.append(NUMBER.charAt(random.nextInt(NUMBER.length())));
        sb.append(SPECIAL_CHARACTERS.charAt(random.nextInt(SPECIAL_CHARACTERS.length())));

        // Shuffle the generated password
        String password = sb.toString();
        char[] passwordArray = password.toCharArray();
        for (int i = 0; i < passwordArray.length; i++) {
            int rndIndex = random.nextInt(passwordArray.length);
            char temp = passwordArray[i];
            passwordArray[i] = passwordArray[rndIndex];
            passwordArray[rndIndex] = temp;
        }
        return new String(passwordArray);
    }

	public void sendNewPasswordByMail(String a_m_mail, String newPassowrd) {
		final MimeMessagePreparator  mimeMessagePreparator = new MimeMessagePreparator() {
			
			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				final MimeMessageHelper mimeMessageHelper 
					= new MimeMessageHelper(mimeMessage,true,"UTF-8");
				mimeMessageHelper.setTo(a_m_mail);
				mimeMessageHelper.setSubject("[ȸ�ź��ʿ�] �� ��й�ȣ �ȳ��Դϴ�.");
				mimeMessageHelper.setText("�� ��й�ȣ : " + newPassowrd);
				
			}
		};
		javaMailSenderImpl.send(mimeMessagePreparator);
	}
}
















