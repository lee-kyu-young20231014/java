package com.myproject.haksa.service;

import java.util.Map;

import com.myproject.haksa.dao.StudentDao;
import com.myproject.haksa.member.Student;

public class StudentAllSelectService {

	private StudentDao studentDao;

	public StudentAllSelectService(StudentDao studentDao) {
		this.studentDao = studentDao;
	}

	public Map<String, Student> allSelect() {
		return studentDao.getStudentDb();
	}

}