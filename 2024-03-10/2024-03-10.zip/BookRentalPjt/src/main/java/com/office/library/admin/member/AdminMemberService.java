package com.office.library.admin.member;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.office.library.util.PasswordGenerator;
@Service
public class AdminMemberService {
	final static public int ADMIN_ACCOUNT_ALREADY_EXIST = 0;
	final static public int ADMIN_ACCOUNT_CREATE_SUCCESS = 1;
	final static public int ADMIN_ACCOUNT_CREATE_FAIL = -1;

	@Autowired
	AdminMemberDao adminMemberDao;
	
	@Autowired
	PasswordGenerator passwordGenerator; 

	public int createAccountConfirm(AdminMemberVo adminMemberVo) {
		boolean isMember = adminMemberDao.isAdminMember(adminMemberVo.getA_m_id());

		if (!isMember) {
			int result = adminMemberDao.insertAdminAccount(adminMemberVo);

			if (result > 0)
				return ADMIN_ACCOUNT_CREATE_SUCCESS;

			else
				return ADMIN_ACCOUNT_CREATE_FAIL;

		} else {
			return ADMIN_ACCOUNT_ALREADY_EXIST;

		}
	}

	public AdminMemberVo loginConfirm(AdminMemberVo adminMemberVo) {
		// TODO Auto-generated method stub
		AdminMemberVo loginedAdminMemberVo =
				adminMemberDao.selectAdmin(adminMemberVo);
		
		
		
		if(loginedAdminMemberVo != null)
			System.out.println("[AdminMemberService] ADMIN MEMBER LOGIN SUCCESS!!");
		else
			System.out.println("[AdminMemberService] ADMIN MEMBER LOGIN FAIL!!");
		
		
		return loginedAdminMemberVo;
	}

	public List<AdminMemberVo> listupAdmin() {		
		return adminMemberDao.selectAdmins();
	}

	public void setAdminApproval(int a_m_no) {
		adminMemberDao.setAdminApproval(a_m_no);
		
	}

	public int modifyAccountConfirm(AdminMemberVo adminMemberVo) {
		return adminMemberDao.modifyAccountConfirm(adminMemberVo);
	}

	public AdminMemberVo getLoginedAdminMemberVo(AdminMemberVo adminMemberVo) {
		// TODO Auto-generated method stub
		return null;
	}

	public int findPasswordConfirm(AdminMemberVo adminMemberVo) {
		AdminMemberVo vo =  adminMemberDao.findPasswordConfirm(adminMemberVo);
		int result = 0;
		if(vo!=null) {
			String newPassowrd = passwordGenerator.generatePassword(10);
			result = adminMemberDao.updatePassword(vo.getA_m_id(), newPassowrd);
			if(result > 0) {
				passwordGenerator.sendNewPasswordByMail(vo.getA_m_mail(), newPassowrd);
			}			
		}
		return result;
	}




}
