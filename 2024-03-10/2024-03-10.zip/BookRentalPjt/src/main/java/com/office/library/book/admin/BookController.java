package com.office.library.book.admin;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.office.library.book.BookVo;
import com.office.library.book.util.UploadFileService;

@Controller
@RequestMapping("book/admin")
public class BookController {
	private static final Logger logger = LoggerFactory.getLogger(BookController.class);
	
	@Autowired
	BookService bookService;

	@Autowired
	UploadFileService uploadFileService;

	@GetMapping("/registerBookForm")
	public String registerBookForm() {
		return "admin/book/register_book_form";
	}

	@PostMapping("/registerBookConfirm")
	public String registerBookConfirm(BookVo bookVo,
			@RequestParam(value = "file", required = false) MultipartFile file) {
		
		// file save
		String nextPage = "admin/book/register_book_ng";
		if (file != null) {
			String savedFileName = uploadFileService.upload(file);
			if (savedFileName != null) {
				bookVo.setB_thumbnail(savedFileName);
				int result = bookService.registerBookConfirm(bookVo);
				if (result > 0)
					nextPage = "admin/book/register_book_ok";
			}
		}
		return nextPage;
	}
	
//	searchBookConfirm?b_name=��
	@GetMapping("searchBookConfirm")
	public String searchBookConfirm(Model model, @RequestParam("b_name") String b_name) 
	{
		List<BookVo> bookVos = bookService.searchBookConfirm(b_name);
		
		logger.info("bookVos : {}",bookVos);
		
		model.addAttribute("bookVos", bookVos);
		return "admin/book/search_book";
	}
	// bookDetail?b_no=1
	@GetMapping("bookDetail")
	public String bookDetail(Model model,  @RequestParam("b_no") int b_no) {
		BookVo bookVo =  bookService.bookDetail(b_no);
		model.addAttribute("bookVo", bookVo);
		return "admin/book/book_detail";
	}
	
	
	
}
